# ShapeCreator

This is our development repository for the ShapeCreator, which we want to really clean up before releasing publically in the graphicsvg repository.

Do not submit code here if you do not want it open-sourced.

If you do not want your contributions acknoweldged when we opensource it, put a note in this readme.

If you have an idea about cleaning up the code, make a note here, or put a -- FIXME comment in the source code.

# Installing Dependencies:

elm init
elm install MacCASOutreach/graphicsvg

# Building:

elm make src/Main.elm

# Notes
## RecursionCreator
Currently the code for RecursionCreator is in file TextCreator.elm. The code for TextCreator has been overwritten, I have trouble to create a new page, so just temporarily using the TextCreator page for the RecursionCreator


